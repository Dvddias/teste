package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import Atxy2k.CustomTextField.RestrictedTextField;
import model.DAO;
import net.proteanit.sql.DbUtils;

import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JDesktopPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPasswordField;

public class Usuarios extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField txtId;
	private JTextField txtNome;
	private JTextField txtLogin;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Usuarios dialog = new Usuarios();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Usuarios() {
		setTitle("Usuarios");
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Usuarios.class.getResource("/img/pc.png")));
		setBounds(100, 100, 621, 364);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JLabel lblNewLabel = new JLabel("ID:");
		lblNewLabel.setBounds(111, 31, 46, 14);
		contentPanel.add(lblNewLabel);

		txtId = new JTextField();
		txtId.setEnabled(false);
		txtId.setBounds(137, 28, 111, 20);
		contentPanel.add(txtId);
		txtId.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Nome:");
		lblNewLabel_1.setBounds(101, 72, 51, 14);
		contentPanel.add(lblNewLabel_1);

		txtNome = new JTextField();
		txtNome.setText("");
		txtNome.setBounds(157, 69, 141, 20);
		contentPanel.add(txtNome);
		txtNome.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("Login:");
		lblNewLabel_2.setBounds(101, 97, 46, 14);
		contentPanel.add(lblNewLabel_2);

		txtLogin = new JTextField();
		txtLogin.setBounds(157, 100, 141, 20);
		contentPanel.add(txtLogin);
		txtLogin.setColumns(10);

		JLabel lblNewLabel_3 = new JLabel("Senha:");
		lblNewLabel_3.setBounds(101, 122, 46, 14);
		contentPanel.add(lblNewLabel_3);

		btnExcluir = new JButton("");
		btnExcluir.setEnabled(false);
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				excluirUsuario();
			}
		});
		btnExcluir.setIcon(new ImageIcon(Usuarios.class.getResource("/img/excluir.png")));
		btnExcluir.setBounds(52, 233, 65, 65);
		contentPanel.add(btnExcluir);

		btnEditar = new JButton("");
		btnEditar.setEnabled(false);
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editarUsuario();
			}
		});
		btnEditar.setIcon(new ImageIcon(Usuarios.class.getResource("/img/edituser.png")));
		btnEditar.setBounds(162, 233, 65, 65);
		contentPanel.add(btnEditar);

		btnNew = new JButton("");
		btnNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adicionarUsuario();
			}
		});
		btnNew.setIcon(new ImageIcon(Usuarios.class.getResource("/img/new (2).png")));
		btnNew.setBounds(271, 233, 65, 65);
		contentPanel.add(btnNew);
		
		cboUser = new JComboBox();
		cboUser.setModel(new DefaultComboBoxModel(new String[] {"", "Administrador", "Usuario"}));
		cboUser.setBounds(157, 184, 91, 22);
		contentPanel.add(cboUser);
		
		JLabel lblNewLabel_4 = new JLabel("Perfil:");
		lblNewLabel_4.setBounds(101, 188, 46, 14);
		contentPanel.add(lblNewLabel_4);
		
		RestrictedTextField nome = new RestrictedTextField(this.txtNome);
		
		JDesktopPane desktopPane = new JDesktopPane();
		desktopPane.setBounds(349, 102, 246, 146);
		contentPanel.add(desktopPane);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 246, 146);
		desktopPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setarCampos();
				setarSenha();
			}
		});
		scrollPane.setViewportView(table);
		
		txtPesquisar = new JTextField();
		txtPesquisar.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				pesquisarUsuario();
			}
		});
		txtPesquisar.setBounds(406, 69, 141, 20);
		contentPanel.add(txtPesquisar);
		txtPesquisar.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("User:");
		lblNewLabel_5.setBounds(372, 72, 46, 14);
		contentPanel.add(lblNewLabel_5);
		
		txtSenha = new JPasswordField();
		txtSenha.setBounds(157, 131, 141, 20);
		contentPanel.add(txtSenha);
		nome.setLimit(50);
	}
	/*RestrictedTextField user = new RestrictedTextField(this.txtNome);
	user.setLimit(50);
	RestrictedTextField senha = new RestrictedTextField(this.txtSenha);
	senha.setLimit(50);*/
// fim do construtor
	DAO dao = new DAO();
	private JButton btnNew;
	private JButton btnEditar;
	private JButton btnExcluir;
	private JComboBox cboUser;
	private JTable table;
	private JTextField txtPesquisar;
	private JPasswordField txtSenha;
	
	
	private void pesquisarUsuario() {
		// ? parametro
		String read = "select id,usuario,login,perfil  from usuario where usuario like ?";
		try {
			// abrir a conexao com o banco
			Connection con = dao.conectar();
			// preparar a query(instrucao sql) para pesquisar no banco
			PreparedStatement pst = con.prepareStatement(read);
			// substituir o parametro(?) Atencao ao % para completar a query
			// 1 ->> parametro(?)
			pst.setString(1, txtPesquisar.getText() + "%");
			// Executar a query e obter os dados do banco (resultado)
			ResultSet rs = pst.executeQuery();
			// popular(preencher) a tabela com os dados do banco
			table.setModel(DbUtils.resultSetToTableModel(rs));
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/**
	 * Metodo responsavel por setar os campos na tabela no formulario
	 */

	private void setarCampos() {
		// a linha abaixo obtem o conteudo da linha da table
		// int (indice = colunns) [0,1,2,3...]
		int setar = table.getSelectedRow();
		// setar os campos
		txtId.setText(table.getModel().getValueAt(setar, 0).toString());
		txtNome.setText(table.getModel().getValueAt(setar,1).toString());
		txtLogin.setText(table.getModel().getValueAt(setar, 2).toString());
		cboUser.setSelectedItem(table.getModel().getValueAt(setar, 3).toString());
		// gerenciar os botoes
		btnNew.setEnabled(false);
		btnEditar.setEnabled(true);
		btnExcluir.setEnabled(true);
	}
	/**
	 * Metodo especifico para setar senha
	 */
	private void setarSenha() {
		String read = "select senha from usuario where id=?";
		try {
			Connection con = dao.conectar();
			PreparedStatement pst = con.prepareStatement(read);
			pst.setString(1, txtId.getText());
			// a linha abaixo executa a instru�ao sql e armazena o resultado no objeto
			// rs(resultado)
			ResultSet rs = pst.executeQuery();
			// a linha abaixo verifica se existe uma senha para o idcli
			if (rs.next()) {
				txtSenha.setText(rs.getString(1));
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	private void adicionarUsuario() {
		// valida�ao de campos obrigatorios
		if (txtNome.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o campo nome", "Aten��o!", JOptionPane.WARNING_MESSAGE);
			txtNome.requestFocus();

		} else if (txtLogin.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o campo Email", "Aten��o!", JOptionPane.WARNING_MESSAGE);
			txtLogin.requestFocus();

		} else if (txtSenha.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o campo Password", "Aten��o!", JOptionPane.WARNING_MESSAGE);
			txtSenha.requestFocus();

		} else {
			
			String create = "insert into usuario (usuario,login,senha,perfil) values (?,?,md5(?),?)";
			try {
				Connection con = dao.conectar();
				PreparedStatement pst = con.prepareStatement(create);
				pst.setString(1, txtNome.getText());
				pst.setString(2, txtLogin.getText());
				pst.setString(3, txtSenha.getText());
				pst.setString(4, (String) cboUser.getSelectedItem());
				
				int confirma = pst.executeUpdate();
				if (confirma == 1) {
					JOptionPane.showMessageDialog(null, "Cliente cadastrado com sucesso!", "Status",
							JOptionPane.INFORMATION_MESSAGE);

				}
				con.close();
				limpar();
				
			} 

			catch (Exception e) {
				System.out.println(e);
			}

		}
	}
	/**
	 * Metodo responsavel pela edi��o dos dados do cliente
	 */
	private void editarUsuario() {

		// valida�ao de campos obrigatorios
		if (txtNome.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o campo nome", "Aten��o!", JOptionPane.WARNING_MESSAGE);
			txtNome.requestFocus();

		} else if (txtLogin.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o campo Login", "Aten��o!", JOptionPane.WARNING_MESSAGE);
			txtLogin.requestFocus();

		} else if (txtSenha.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o campo Senha", "Aten��o!", JOptionPane.WARNING_MESSAGE);
			txtSenha.requestFocus();
		}else if (cboUser.getSelectedItem().equals("")) {
				JOptionPane.showMessageDialog(null, "Preencha o perfil.", "Aten��o!", JOptionPane.WARNING_MESSAGE);
				cboUser.requestFocus();

		} else {
			
			String update = "update usuario set usuario=?,login=?,senha=md5(?), perfil=? where id=?";
			try {
				Connection con = dao.conectar();
				PreparedStatement pst = con.prepareStatement(update);
				pst.setString(1, txtNome.getText());
				pst.setString(2, txtLogin.getText());
				pst.setString(3, txtSenha.getText());
				pst.setString(4, txtId.getText());
				pst.setString(5, (String) cboUser.getSelectedItem());
				// criando uma variavel que ira executar a query e receber o valor 1 em caso
				// positivoEdi��o do cliente no banco)
				int confirma = pst.executeUpdate();
				if (confirma == 1) {
					JOptionPane.showMessageDialog(null, "Dados do Usuario atualizados com sucesso!", "Mensagem",
							JOptionPane.INFORMATION_MESSAGE);

				}
				con.close();
				limpar();
				// o catch abaixo se refere ao valor dupliacdo do email (unique)
			} 

			catch (Exception e) {
				System.out.println(e);
			}

		}
	}
	
	private void excluirUsuario() {
		// confima��o de exclus�o
		int confirma = JOptionPane.showConfirmDialog(null, "Confirma a exclus�o deste usu�rio?", "Aten��o!",
				JOptionPane.YES_NO_OPTION);
		if (confirma == JOptionPane.YES_OPTION) {
			// codigo princial
			String delete = "delete from usuario where id=?";
			try {
				Connection con = dao.conectar();
				PreparedStatement pst = con.prepareStatement(delete);
				pst.setString(1, txtId.getText());
				int excluir = pst.executeUpdate();
				if (excluir == 1) {
					limpar();
					JOptionPane.showMessageDialog(null, "Usuario excluido!", "Mensagem",
							JOptionPane.INFORMATION_MESSAGE);
				}

				con.close();

			} catch (java.sql.SQLIntegrityConstraintViolationException ex) {
				JOptionPane.showMessageDialog(null, " Exclusao negada!","Aten�ao!",
						JOptionPane.WARNING_MESSAGE);

			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}
	/**
	 * Metodo usado para Limpar os campos e gerenciar os botoes
	 */
	private void limpar() {
		// limpar campos
		txtId.setText(null);
		txtNome.setText(null);
		txtLogin.setText(null);
		txtSenha.setText(null);
		
		
		
		// genrencia botoes
		btnNew.setEnabled(true);
		btnEditar.setEnabled(false);
		btnExcluir.setEnabled(false);
	}
}
